import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrangeAccent,
        title: Text("Home Screen"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Text(
            "Hello in home screen",
            style: TextStyle(color: Colors.red, fontSize: 30),
          ),
          Icon(
            Icons.person,
            color: Colors.red,
            size: 60,
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: TextFormField(),
          ),
          Container(width: 100, height: 100, child: Image.asset("assets/dart.png")),
          MaterialButton(
            onPressed: () {},
            child: Text("Hello"),
          )
        ],
      ),
    );
  }
}
